[![Build Status](https://travis-ci.org/StatsWithR/statsr.svg?branch=master)](https://travis-ci.org/StatsWithR/statsr)

# statsr

Companion package for the Coursera *Statistics with R* specialization
